<?php
include('serv/autob/bt.php');
include('serv/autob/basicbot.php');
include('serv/autob/uacrawler.php');
include('serv/autob/refspam.php');
include('serv/autob/ipselect.php');
include('serv/autob/bts2.php');
?>
