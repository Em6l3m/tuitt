<?php
$settings = array(
	"adminpanel"			=> "1",
        "adminpass"			=> "Tees",
          
        
);
return $settings;
?>



//admin panel settings

// open the serv folder/settings.php to locate main settings	